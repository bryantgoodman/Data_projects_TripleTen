View Tableau project here:

https://public.tableau.com/views/BryantGoodman-Sprint4Projectfixed/ProfitLossOverview?:language=en-US\&publish=yes&:sid=&:redirect=auth&:display\_count=n&:origin=viz\_share\_link